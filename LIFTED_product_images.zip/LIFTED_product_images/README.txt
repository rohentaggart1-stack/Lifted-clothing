LIFTED PRODUCT IMAGES

Put the entire images folder into the root of your GitHub repository.

Files included:
- hoodie.jpg
- tee.jpg
- shorts.jpg
- pants.jpg
- beanie.jpg

Note: the separate denim image was not included in the uploaded images available to me in this turn.
