# LIFTED — GitHub Pages

Upload the contents of this folder to the root of your GitHub repository.

Then go to **Settings → Pages → Build and deployment → Deploy from a branch**, choose **main** and **/(root)**, and press **Save**.

No build step is required.
